-- Table: public."PRODUCTS"


CREATE TABLE public."PRODUCTS"
(
    "PRODUCT_CODE" numeric(10,0) NOT NULL,
    "CATEGORY" character varying(10) COLLATE pg_catalog."default" NOT NULL,
    "NAME" character varying(20) COLLATE pg_catalog."default" NOT NULL,
    "PURCHASE_DATE" date NOT NULL,
    "PURCHASE_QUANTITY" numeric(10,0) NOT NULL,
    "PURCHASE_PRICE" double precision NOT NULL,
    "SALE_DATE" date,
    "SALE_QUANTITY" numeric(10,0),
    "SALE_PRICE" double precision,
    CONSTRAINT "PRODUCTS_pkey" PRIMARY KEY ("PRODUCT_CODE")
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public."PRODUCTS"
    OWNER to postgres;