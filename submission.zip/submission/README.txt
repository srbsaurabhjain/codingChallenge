CONFIGURATION CHANGES:

Backend:
1. src code for backend is present in backend folder by the name "profectusChallenge.zip".
2. This needs to be extracted and should be imported in Spring Tool Suite or Eclipse IDE.
3. Once imported in STS or eclispse the project can run by running "ProductApplication" file.
4. After successful importing project should be run Maven Clean, Maven Install.
5. Junit 4 is used for testing the classes with Mockito.

Database:
1. New database should be created in postgres with name "profectus" or any other [name].
2. Scripts file table.sql from the sql folder should be executed in newly created database.
3. Property "spring.datasource.url" in application.properties file at the path src\main\resources\application.properties should be updated 	with the "jdbc:postgresql://localhost:5432/[name]", name will be of the database created in Step-1.
4. Property "spring.datasource.username" and "spring.datasource.password" should be updated with your postgres username and password.

Frontend:
1. Angular CLI should be installed from the steps through url https://www.geeksforgeeks.org/angular-cli-angular-project-setup/
2. Once above setup is completed the "myNewApp" folder will generate and under that src folder will be available this src folder should be replaced with frontend src from the folder frontend.
3. Now we can hit the url for accessing application http://localhost:4200/


ASSUMPTIONS:
1. There are only two categories for the products i.e. Dairy and Fruit. New Categories can be added as it is drop down.
2. Sold details will be given once, i.e. if sold details added for a product multiple times then it will overwrite previous sold details.
3. Profit for a single product is calculated: Sale price - (purchasePrice/purchaseQuantity * SaleQuantity) 

Note: Refer the profectus challenge document for program structure and test cases


